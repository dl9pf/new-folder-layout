#!/bin/sh

echo "Update firmware for cameras {0-3} to default (original) RDCAM21/RDCAM24"

v4l2-fw -v -d /dev/video0 -W -w /usr/share/factory/rdcam21.rdcam24.1280x1080@30.bin
v4l2-fw -v -d /dev/video1 -W -w /usr/share/factory/rdcam21.rdcam24.1280x1080@30.bin
v4l2-fw -v -d /dev/video2 -W -w /usr/share/factory/rdcam21.rdcam24.1280x1080@30.bin
v4l2-fw -v -d /dev/video3 -W -w /usr/share/factory/rdcam21.rdcam24.1280x1080@30.bin

echo "Power off system to take effect for firmware update"
