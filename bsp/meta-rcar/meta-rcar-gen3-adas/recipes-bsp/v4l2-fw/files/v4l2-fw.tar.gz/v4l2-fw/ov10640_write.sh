#!/bin/sh

dev=/dev/video0

let high=$1/256
let low=$1%256
let val=$2

# write register to ov10640:
v4l2-dbg -d $dev -c subdev0 -s 0xfffd 0x80
v4l2-dbg -d $dev -c subdev0 -s 0xfffe 0x19
v4l2-dbg -d $dev -c subdev0 -s 0x5000 0x0
v4l2-dbg -d $dev -c subdev0 -s 0x5001 $high
v4l2-dbg -d $dev -c subdev0 -s 0x5002 $low
v4l2-dbg -d $dev -c subdev0 -s 0x5003 $val
v4l2-dbg -d $dev -c subdev0 -s 0xfffe 0x80
v4l2-dbg -d $dev -c subdev0 -s 0xc0 0xc1
