#!/bin/sh

dev=/dev/video0

let high=$1/256/256/256
let low=($1/256/256)%256
let reg=$1%65536
let val=$2

# write register to ov490:
v4l2-dbg -d $dev -c subdev0 -s 0xfffd $high
v4l2-dbg -d $dev -c subdev0 -s 0xfffe $low
v4l2-dbg -d $dev -c subdev0 -s $reg $val
